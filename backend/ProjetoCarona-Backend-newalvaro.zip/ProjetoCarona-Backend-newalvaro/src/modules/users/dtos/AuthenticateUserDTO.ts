export interface AuthenticateUserDTO {
  email: string;
  password: string;
}
