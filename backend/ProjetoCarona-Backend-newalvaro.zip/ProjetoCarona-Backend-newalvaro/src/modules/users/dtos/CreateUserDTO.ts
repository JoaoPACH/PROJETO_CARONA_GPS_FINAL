export interface CreateUserDTO {
  firstName: string;
  lastName: string;
  email: string;
  telefone: string;
  password: string;
}
